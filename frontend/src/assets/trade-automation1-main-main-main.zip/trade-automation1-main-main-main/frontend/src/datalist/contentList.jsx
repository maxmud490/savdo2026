import monitoring from '../assets/monitoring.svg'
import box from '../assets/box-icon.svg'
import data from '../assets/big-data.svg'
import handshake from '../assets/handshake.svg'
import clients from '../assets/clients.svg'
export const contentList = [
    { id: 1, title: 'Bosh sahifa', icon: monitoring },
     { id: 2, title: 'Mahsulotlar', icon: box},
     { id: 3, title: 'Ombor', icon: data },
     { id: 4, title: 'Yetkazuvchilar', icon: handshake },
     { id: 5, title: 'Mijozlar', icon: clients },
  ];

