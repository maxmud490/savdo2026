


import {
    faCartShopping,
    faBasketShopping,
    faInbox,
    faReply,
    faHandHoldingUsd,
    faHistory,
    faDatabase,
    faSync,
    faKey,
    faFolderClosed,
    faPhone,
    faCalendarDays,
    faHandshake
  } from '@fortawesome/free-solid-svg-icons';
  
  export const dropListItems = {
    product: [
      { id: 1, title: "Mahsulotlar ro'yxati", icon: faCartShopping },
      { id: 2, title: "Sotuvlar ro'yxati", icon: faBasketShopping },
      { id: 3, title: "Tushirilgan mahsulotlar ro'yxati", icon: faInbox },
      { id: 4, title: "Qaytgan mahsulotlar ro'yxati", icon: faReply },
      { id: 5, title: "Buyurtmalar ro'yxati", icon: faHandHoldingUsd },
      { id: 6, title: "Mahsulotlar tarixi", icon: faHistory },
    ],
    base: [
      { id: 7, title: "Omborlar ro'yxati", icon: faDatabase },
      { id: 8, title: "Transferlar ro'yxati", icon: faSync },
      { id: 9, title: "Omborlar ro'yxati", icon: faKey },
    ],
    provider: [
        { id: 10, title: "Yetkazib beruvchilar ro'yxati", icon: faFolderClosed },
        { id: 11, title: "To'langan qarzlar ro'yxati", icon: faHandHoldingUsd },
        { id: 12, title: "Yetkazib beruvchilarni kontaklari", icon: faPhone },
      ],
      client: [
        { id: 13, title: "Mijozlar ro'yxati", icon: faFolderClosed },
        { id: 14, title: "To'lovlar ro'yxati", icon: faHandHoldingUsd },
        { id: 15, title: "Mijozlarni telefon raqamlari", icon: faPhone },
      ],
  };

export const salesInformation = [
  { id: 16, title: "Bugun", icon: faCalendarDays },
  { id: 17, title: "Неделя", icon: faCalendarDays },
  { id: 18, title: "Месяц", icon: faCalendarDays },
  { id: 19, title: "Bizga qarz", icon: faHandHoldingUsd },
  { id: 20, title: "Bizning qarzimiz", icon: faHandshake },
]
  





