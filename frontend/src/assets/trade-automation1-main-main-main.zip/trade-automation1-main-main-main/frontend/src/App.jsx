import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import "./App.css";
import Dashboard from "./components/Dashboard";
import HomePage from "./components/HomePage";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import ProductDetail from "./components/product/ProductDetail";
import SalesList from "./components/sales/SalesList";
import axios from "axios";
import Login from "./components/Login";
import { ToastContainer, toast } from 'react-toastify';
import { v4 as uuidv4 } from 'uuid';



function App() {
  const [showContent, setShowContent] = useState(true);
  const [value, setValue] = useState("");
  const [clientData, setClientData] = useState([]);
  const [salesOpenModal, setSalesOpenModal] = useState(false);
  const [totalValue, setTotalValue] = useState(0);
  const [allTotalValue, setAllTotalValue] = useState(0);
  const [showClientModal, setShowClientModal] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [buttonDisabled,setButtonDisabled] = useState(false)
  const [loading, setLoading] = useState(true);
  const [salesData, setSalesData] = useState({
    dataValue: "",
    clientName: "",
    productPrice: "",
    workman: "",
    productNameValue: "",
    productNumber: "",
    creationDateTime: ""
  });

  const [salesArray, setSalesArray] = useState([]);
  const [productData, setProductData] = useState({
    productName: "",
    turkum: "",
    sotishNarxi: "",
    ulgurjiNarxi: "",
    sotibOlinganNarxi: "",
    olchovBirligi: "",
    oramlarNomi: "",
    oramlarSoni: "",
  });


  const [productArray, setProductArray] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState({
    userId: null,
    token: null,
  });

  const onLogin = ({ token, userId }) => {
    setIsLoggedIn(true);
    console.log('User logged in with ID:', userId);
    console.log('Token:', token);

    // Update userInfo state with userId and token
    setUserInfo({
      userId: userId,
      token: token,
    });
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserInfo({
      userId: null,
      token: null,
    });
   
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProductData((prevData) => ({ ...prevData, [name]: value }));
  };


  const fetchProductData = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/products");
      setProductArray(response.data.products);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  useEffect(() => {
    fetchProductData();
  }, []);


  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const newProductData = {
        id: uuidv4(),
        ...productData,
      };
      await axios.post("http://localhost:5000/api/products", newProductData);

      setProductData({
        productName: "",
        turkum: "",
        sotishNarxi: "",
        ulgurjiNarxi: "",
        sotibOlinganNarxi: "",
        olchovBirligi: "",
        oramlarNomi: "",
        oramlarSoni: "",
      });
      setShowModal(false);
      fetchProductData();
    } catch (error) {
      console.error("Error in handleSubmit:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSalesData((prevData) => ({ ...prevData, [name]: value }));
  };

  useEffect(() => {
    const newTotalValue = Number(salesData.productNumber) * Number(salesData.productPrice);
    setTotalValue(newTotalValue);
  }, [salesData.productNumber, salesData.productPrice]);
  

  const calculateTotalValue = (item) => {
    return Number(item.productNumber) * Number(item.productPrice);
  };

  useEffect(() => {
    const newTotalValue = salesArray.reduce(
      (total, salesItem) => total + calculateTotalValue(salesItem),
      0
    );
    setAllTotalValue(newTotalValue);
  }, [salesArray]);

  const handleDecrement = () => {
    const product = productArray.find(
      (product) =>
        product.productName.toLowerCase() ===
        salesData.productNameValue.toLowerCase()
    );

    if (product) {
      const updatedProductArray = productArray.map((p) =>
        p.productName.toLowerCase() === salesData.productNameValue.toLowerCase()
          ? {
              ...p,
              oramlarSoni: (p.oramlarSoni || 0) - salesData.productNumber,
            }
          : p
      );

      setProductArray(updatedProductArray);
    }
  };


const handleSubmit = async (e) => {
  e.preventDefault();

  try {

    const { productNameValue, productNumber} = salesData;
    const newSales = {
      id: uuidv4(),
      creationDateTime: salesData.creationDateTime || Date.now(),
      ...salesData,
    };
    const resultSales = {
      productNameValue,
      productNumber
    }

    const newArray = [...salesArray, newSales];
    setSalesArray(newArray);

    // Use useEffect to log the updated salesArray

    handleDecrement();

    setSalesData({
      id: uuidv4(),
      dataValue: "",
      clientName: "",
      productPrice: "",
      workman: "",
      productNameValue: "",
      productNumber: "",
      creationDateTime: "",
    });

    setButtonDisabled(true);

    // Make a POST request using Axios
    const response = await axios.post("http://localhost:5000/api/resultSales", resultSales);

    // Check if the request was successful (status code 2xx)
    if (response.status === 200 || response.status === 201) {
      console.log('Sales data successfully submitted to the server');
    } else {
      console.error('Failed to submit sales data to the server');
    }

  } catch (error) {
    console.error(error);
  }
};

  
  useEffect(() => {
    console.log("Updated salesArray:", salesArray);
  }, [salesArray]);

  const handleClickClient = () => {
    setShowClientModal(true);
  };

  const handleSalesModal = () => {
    setSalesOpenModal(true);
  };

  const handleCloseModal = () => {
    setSalesOpenModal(false);
  };

  useEffect(() => {
    const savedClientArray = JSON.parse(localStorage.getItem("clientData")) || [];
    setClientData((prevClientData) => {
      if (prevClientData !== savedClientArray) {
        console.log("Previous Client Data:", prevClientData);
      }
      return savedClientArray;
    });
  }, []);

  const fetchClientData = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/clients");
      setClientData(response.data.clients);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  useEffect(() => {
    fetchClientData();
  }, []);

  const handleClientSubmit = async (e) => {
    e.preventDefault();

    try {
      const currentClientData = [...clientData];
      let totalNewPriceNumber = 0; // Accumulator for newPriceNumber
     let totalPrice = 0;
      const combinedClientItem = salesArray.reduce((accumulator, current) => {
        const clientItem = {
          clientName: current.clientName,
          dataValue: current.dataValue,
          productNameValue: current.productNameValue,
          workman: current.workman,
          clientValue: value,
          creationDateTime: new Date(),
          id: current.id,
          productNumber: current.productNumber,
          newPrice: allTotalValue,
          newPriceNumber: current.productNumber * current.productPrice,
        };

        // Accumulate newPriceNumber
        totalNewPriceNumber += clientItem.newPriceNumber;
        totalPrice = clientItem.newPrice;

        // Set state and local storage for each item
        const newClientData = [...currentClientData, clientItem];
        setClientData(newClientData);
        

        return {
          ...accumulator,
          ...clientItem,
        };
      }, {});

      // Set the accumulated newPriceNumber
      combinedClientItem.newPriceNumber = totalNewPriceNumber;
      combinedClientItem.newPrice = totalPrice;
      // Send the combined clientItem to the server
      const response = await axios.post("http://localhost:5000/api/clients", {
        clientData: combinedClientItem,
      });
      console.log("Axios Response:", response);
 
      // Reset the local state
      setValue("");
      setSalesArray([]);
      setShowClientModal(false);
      setSalesOpenModal(false)

      // Additional logic if needed after successful submission
    } catch (error) {
      console.error("Error in handleClientSubmit:", error);
    }
  };
  console.log(clientData);
  const handleDelete = async (id) => {
    try {
     
      const response = await axios.delete(`http://localhost:5000/api/clients/${id}`);
  
      if (response.data.success) {
        const updatedArray = clientData.filter((item) => item.id !== id);
        setClientData(updatedArray);
        fetchClientData();
        toast.success("Mijozni muvafaqqiyatli o'chirildi.", {
          position: 'top-right',
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      } 
    } catch (error) {
      console.error('Error in handleDelete:', error);
  
      toast.error("Mijozni oʻchirishda xatolik yuz berdi.", {
        position: 'top-right',
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  };

  const handlerShowContent = () => {
    setShowContent((prev) => !prev);
  };


  return (
    <>
   {isLoggedIn ? (
    <BrowserRouter>
    <>
    <ToastContainer/>
      <Navbar handlerShowContent={handlerShowContent} handleLogout={handleLogout} />
      <Dashboard showContent={showContent} />
      <Routes>
        <Route path="/" element={<HomePage clientData={clientData} />} />
        <Route
          path="/1"
          element={
            <ProductDetail
              handleFormSubmit={handleFormSubmit}
              handleInputChange={handleInputChange}
              productArray={productArray}
              productData={productData}
              showModal={showModal}
              setShowModal={setShowModal}
              setProductArray={setProductArray}
              loading={loading}
              fetchProductData={fetchProductData}
            />
          }
        />
        <Route
          path="/2"
          element={
            <SalesList
              salesArray={salesArray}
              handleSalesModal={handleSalesModal}
              clientData={clientData}
              salesOpenModal={salesOpenModal}
              handleCloseModal={handleCloseModal}
              handleClickClient={handleClickClient}
              handleSubmit={handleSubmit}
              salesData={salesData}
              handleChange={handleChange}
              totalValue={totalValue}
              allTotalValue={allTotalValue}
              showClientModal={showClientModal}
              setShowClientModal={setShowClientModal}
              setSalesData={setSalesData}
              setSalesArray={setSalesArray}
              handleClientSubmit={handleClientSubmit}
              value={value}
              setValue={setValue}
              handleDelete={handleDelete}
              productArray={productArray}
              loading={loading}
              buttonDisabled={buttonDisabled}
              setButtonDisabled={setButtonDisabled}
            />
          }
        />
      </Routes>
    </>
</BrowserRouter>
   ) :(
    <Login onLogin={onLogin} />
   ) }
      
    </>
  );
}

export default App;
