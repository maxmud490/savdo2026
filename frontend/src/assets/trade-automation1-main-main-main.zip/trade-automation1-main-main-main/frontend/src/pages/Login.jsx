import { useState } from "react";
import axios from "axios";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/login', { username, password });
      console.log('Login response:', response.data);
      setMessage(response.data.message);
    } catch (error) {
      console.error('Error during login:', error);
      setMessage('An error occurred during login');
    }
  };
  
  return (
    <div style={{ width: "100%", marginLeft: "140px", marginTop: "140px" }}>
      <h1>Login</h1>
      <div>
        <label>Username: </label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div>
        <label>Password: </label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button className ="btn btn-danger" onClick={handleLogin}>Login</button>
      <p>{message}</p>
    </div>
  );
}

export default Login;
