import React from 'react'

function SalesEditComponent() {
  return (
    <div>SalesEditComponent</div>
  )
}

export default SalesEditComponent