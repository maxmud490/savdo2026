import PropTypes from "prop-types";

function ModalComponent({
  handleCloseModal,
  handleFormSubmit,
  handleInputChange,
  productData,
  productArray,
}) {
  return (
    <>
      <div className="modal_container">
        <form onSubmit={handleFormSubmit}>
          <div className="modal_content p-4">
            <div className="row">
              <div className="col-6">
                <h1>
                  <span style={{ fontSize: "1.2rem" }}>
                    Yangi mahsulot qoshish
                  </span>
                </h1>
              </div>
              <div className="col-6">
                <div className="float-right">
                  <button
                    type="submit"
                    className="btn shadow-sm btn-orange mr-5"
                  >
                    Saqlash
                  </button>
                  <span className="close" onClick={handleCloseModal}>
                    &times;
                  </span>
                </div>
              </div>

              <div className="col-8">
                <h6 className="text-orange">Mahsulot nomi</h6>
                <div className="card shadow p-5 mt-1 mb-3">
                  <div className="  mb-3">
                    <label className="form-label w-100">
                      Mahsulot nomi <span className="text-orange">*</span>
                      <div className="input-container">
                        <input
                          name="productName"
                          value={productData.productName}
                          onChange={handleInputChange}
                          type="text"
                          className="form-control"
                          style={
                            productArray.some(
                              (product) => product.productName === productData.productName
                            )
                              ? { borderColor: 'red', borderBottomWidth: "3px" }
                              : {}
                          }
                          required
                        />
                        {productArray.some(
                          (product) =>
                            product.productName === productData.productName
                        ) ? (
                          <span className="message">
                            Bu maxsulot omborda mavjud
                          </span>
                        ) : null}
                      </div>
                    </label>

                    <div className="mb-3">
                      <label className="form-label w-100">
                        Turkum
                        <input
                          name="turkum"
                          placeholder="Turkumni tanlang"
                          value={productData.turkum}
                          onChange={handleInputChange}
                          className="form-control"
                          list="datalistOptions"
                        />
                        <datalist id="datalistOptions">
                          <option value="San Francisco" />
                          <option value="New York" />
                          <option value="Seattle" />
                          <option value="Los Angeles" />
                          <option value="Chicago" />
                        </datalist>
                      </label>
                    </div>
                  </div>
                </div>
                <h6 className="text-orange">Olchov birligi</h6>
                <div className="card shadow p-5 mt-1">
                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Olchov birligi <span className="text-orange">*</span>
                      <input
                        name="olchovBirligi"
                        placeholder=" dona,kg,m"
                        value={productData.olchovBirligi}
                        onChange={handleInputChange}
                        type="text"
                        className="form-control"
                        required
                      />
                    </label>
                  </div>

                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Oramlar nomi
                      <input
                        name="oramlarNomi"
                        placeholder="quti,paket,o'ram"
                        value={productData.oramlarNomi}
                        onChange={handleInputChange}
                        type="text"
                        className="form-control"
                      />
                    </label>
                  </div>
                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Oramlar soni
                      <input
                        name="oramlarSoni"
                        value={productData.oramlarSoni}
                        onChange={handleInputChange}
                        type="number"
                        className="form-control"
                      />
                    </label>
                  </div>
                </div>
              </div>
              <div className="col-4">
                <h6 className="text-orange">Narxi</h6>
                <div className="card shadow p-5 mt-1">
                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Sotish narxi <span className="text-orange">*</span>
                      <input
                        name="sotishNarxi"
                        value={productData.sotishNarxi}
                        onChange={handleInputChange}
                        type="number"
                        className="form-control"
                        required
                      />
                    </label>
                  </div>

                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Ulgurji narxi
                      <input
                        name="ulgurjiNarxi"
                        value={productData.ulgurjiNarxi}
                        onChange={handleInputChange}
                        type="number"
                        className="form-control"
                      />
                    </label>
                  </div>
                  <div className=" mb-3">
                    <label className="form-label w-100">
                      Sotib olingan narxi
                      <input
                        name="sotibOlinganNarxi"
                        value={productData.sotibOlinganNarxi}
                        onChange={handleInputChange}
                        type="number"
                        className="form-control"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  );
}
ModalComponent.propTypes = {
  handleCloseModal: PropTypes.func.isRequired,
  handleFormSubmit: PropTypes.func.isRequired,
  handleInputChange: PropTypes.func.isRequired,
  productData: PropTypes.object.isRequired,
};
export default ModalComponent;
