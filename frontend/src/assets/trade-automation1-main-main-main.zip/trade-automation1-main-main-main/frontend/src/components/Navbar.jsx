
import "bootstrap/dist/css/bootstrap.min.css";
import burger from "../assets/burger-menu.svg";
import telegram from "../assets/telegram-logo.svg";
import coins from "../assets/coin.svg";
import grid from "../assets/grid.svg";
import screen from "../assets/size-fullscreen.svg";
import cloud from "../assets/cloud.svg";
import cash from '../assets/cash.svg'
import bell from '../assets/bell-860.svg'

// Import statements...

const Navbar = ({ handlerShowContent, handleLogout }) => {
  return (
    <nav className="navbar navbar-light bg-white shadow fixed-top">
      <div className="container-fluid">
        <div className="d-flex justify-content-between w-100">
          <div className="d-flex items-center">
            <div style={{ cursor: 'pointer' }}>
              <img
                src={burger}
                alt="burger-menu"
                className="px-4"
                onClick={handlerShowContent}
              />
            </div>
            <div className="mx-3">
              <button type="button" className="btn btn-orange btn-sm">
                Основной склад
              </button>
            </div>

            <button type="button" className="btn btn-red btn-sm">
              O'zbekcha
            </button>
          </div>
          <div className="logo-text">
            <h1 title="hippo.uz">Hippo.uz</h1>
          </div>

          <div className="d-flex w-400">
            <div className="d-flex">
              <a href="https://t.me/yourTelegramChannel" className="mr-4">
                <img
                  src={telegram}
                  alt="telegram-icon"
                  className="card-img-left"
                  style={{ width: "27px" }}
                />
              </a>
              <img src={coins} alt="coins" style={{ width: "16px" }} className="mr-2" />
              <span className="balans mr-4 hover">Balans: 0</span>
            </div>
            <div className="d-flex">
              <img
                className="mr-4 hover"
                src={grid}
                alt="grid-icon"
                style={{ width: "16px" }}
              />
              <img
                className="mr-4 hover"
                src={screen}
                alt="screen-icon"
                style={{ width: "16px" }}
              />
              <img
                className="mr-4 hover"
                src={cloud}
                alt="cloud-icon"
                style={{ width: "20px" }}
              />
              <img
                className="mr-4 hover"
                src={cash}
                alt="cash-icon"
                style={{ width: "20px" }}
              />
            </div>
            <div className="d-flex align-items-center justify-content-center">
              <img src={bell} alt="bell-icon" />
              <button 
              onClick={handleLogout}
              className="btn btn-primary">Chiqish</button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;


