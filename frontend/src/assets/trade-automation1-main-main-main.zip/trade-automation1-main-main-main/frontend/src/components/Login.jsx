import axios from "axios";
import { useEffect, useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Login({ onLogin }) {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const changeHandler = (event) => {
    setForm({ ...form, [event.target.name]: event.target.value });
  };

  const login = (token, userId) => {
    // Implement your login logic here
    console.log("Login successful!");
    console.log("Token:", token);
    console.log("User ID:", userId);
    // You can redirect or perform other actions upon successful login
  };

  const loginHandler = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        "http://localhost:5000/api/login",
        { ...form },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.data) {
        const { token, userId } = response.data;
        login(token, userId);
        onLogin(token, userId);

        toast.success("Muvafaqqiyatli !.", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log(error.message);
      toast.error("Email yoki parolni to'gri kiriting !", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  };

  return (
    <>
      <ToastContainer />
      <div className="main-content">
        <div className="container">
          <div className="row">
            <div className="col-6 offset-3">
              <main className="form-signin bg-info text-white p-5 rounded-md">
                <form onSubmit={loginHandler} >
                  <div className="mb-3">
                    <label htmlFor="exampleInputEmail1" className="form-label">
                      Email address
                    </label>
                    <input
                      name="email"
                      value={form.email}
                      onChange={changeHandler}
                      required
                      type="email"
                      className="form-control"
                    />
                  </div>
                  <div className="mb-3">
                    <label
                      htmlFor="exampleInputPassword1"
                      className="form-label"
                    >
                      Password
                    </label>
                    <input
                      name="password"
                      value={form.password}
                      onChange={changeHandler}
                      required
                      type="password"
                      className="form-control"
                    />
                  </div>
                  <button className="btn btn-primary float-end">Submit</button>
                </form>
              </main>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
