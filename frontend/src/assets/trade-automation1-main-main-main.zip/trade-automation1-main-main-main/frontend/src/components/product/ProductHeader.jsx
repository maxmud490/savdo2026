import PropTypes from 'prop-types';
import ButtonOrange from '../ButtonOrange';
import ButtonRed from '../ButtonRed';
import { useState } from 'react';

function ProductHeader({
  OpenModal,
  title,
  excelButtonLabel,
  filterButtonLabel,
  loadExcelButtonLabel,
  addProduct,
  itemTable,
  setSearchProduct,
  searchProduct
}) {
  
  return (
    <div className="row">
      <div className="col-2">
        <div className="d-flex align-items-center">
          <h3 style={{ fontSize: "1.2rem" }}>{title}</h3>
        </div>
      </div>
      <div className="col-10">
        <div className="text-right">
          <button
            type="button"
            className="btn w-xs-100 my-1 btn-red btn-sm mr-1"
          >
            {excelButtonLabel}
          </button>
          <ButtonOrange 
          onClick={OpenModal}
          >
            {addProduct}
          </ButtonOrange>
          <ButtonRed>
          {loadExcelButtonLabel}
          </ButtonRed>
        </div>
      </div>
      <div className="col col-12">
        <div className="row">
          <div className="col-6">
            <div className="d-flex mr-auto mt-5">
              <div className=" mr-2 d-block my-2  w-sm-100 btn-group">
                <ButtonOrange>
                {itemTable}
                </ButtonOrange>
              </div>
              <div className="search-sm mr-1 my-2">
                <input
                  type="search"
                  className="form-control form-control-dark rounded-pill"
                  placeholder=" Qidiruv..."
                  value={searchProduct}
                  onChange={event => setSearchProduct(event.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="d-flex align-items-center justify-end  mt-5">
              <div className="my-2 mr-1">
                <label className="pr-2">Korsatish:</label>
                <div className="d-inline-block btn-group">
                  <button className="btn btn-outline-warning rounded-50 btn-xs">
                    10
                  </button>
                </div>
              </div>
              <div>
                <ButtonOrange>
                {filterButtonLabel}
                </ButtonOrange>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
ProductHeader.propTypes = {
  OpenModal: PropTypes.func.isRequired, // Ensure OpenModal is a function and is required
  title: PropTypes.string.isRequired,
  excelButtonLabel: PropTypes.string.isRequired,
  filterButtonLabel: PropTypes.string.isRequired,
  loadExcelButtonLabel: PropTypes.string.isRequired,
  addProduct: PropTypes.string.isRequired,
  itemTable: PropTypes.string.isRequired,
};

export default ProductHeader;
