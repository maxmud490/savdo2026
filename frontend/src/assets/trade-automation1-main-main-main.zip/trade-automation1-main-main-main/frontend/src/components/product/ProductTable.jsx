import { useState } from "react";
import TableHeader from "./TableHeader";
import TableBody from "./TableBody";
import EditModal from "./EditModal";
import ConfirmDelete from "./ConfirmDelete";
import PropTypes from "prop-types";

function ProductTable({ productArray, deleteItem, loading, fetchProductData,filteredProduct,setSearchProduct,searchProduct}) {
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [itemIdToDelete, setItemIdToDelete] = useState(null);
  const [showEditProductModal, setShowEditProductModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  

  const openDeleteModal = (id) => {
    setItemIdToDelete(id);
    setShowDeleteModal(true);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setItemIdToDelete(null);
  };

  const confirmDelete = () => {
    if (itemIdToDelete) {
      deleteItem(itemIdToDelete);
      closeDeleteModal();
    }
  };
  const handleEditProduct = (id) => {
    const productToEdit = productArray.find((product) => product.id === id);
    setEditProduct(productToEdit);
    setShowEditProductModal(true);
  };
  const handleCloseModal = () => {
    // Implement the logic to close the modal
    setShowEditProductModal(false);
  };

  return (
    <div className="row">
      <div className="col-12">
        <div className="card mb-4 table-container">
          <div className="card-body p-5">
            <h3 style={{ fontSize: "1.2rem" }}>Mahsulotlar royxati</h3>
            <table className="table table-bordered mt-3">
              <TableHeader
              
              />
              <TableBody
              setSearchProduct={setSearchProduct}
              searchProduct={searchProduct}
                productArray={productArray}
                openDeleteModal={openDeleteModal}
                loading={loading}
                handleEditProduct={handleEditProduct}
                filteredProduct={filteredProduct}
              />
            </table>
          </div>
        </div>
      </div>
      {showDeleteModal && (
        <div className="modal_container">
          <ConfirmDelete
            confirmDelete={confirmDelete}
            closeDeleteModal={closeDeleteModal}
          />
        </div>
      )}
        <>
          {showEditProductModal && (
            <EditModal
              handleCloseModal={handleCloseModal}
              editProduct={editProduct}
              setEditProduct={setEditProduct}
              fetchProductData={fetchProductData}
            />
          )}
        </>
      
    </div>
  );
}
ProductTable.propTypes = {
  productArray: PropTypes.array.isRequired, // Ensure productArray is an array and is required
  deleteItem: PropTypes.func.isRequired,
};
export default ProductTable;
