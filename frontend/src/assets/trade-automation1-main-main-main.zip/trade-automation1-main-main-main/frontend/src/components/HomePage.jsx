import "./HomePage.css";
import { salesInformation } from "../datalist/dropListItems";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";

function HomePage({ clientData }) {
  function formatLargeNumber(number) {
    if (typeof number !== 'undefined' && number !== null) {
      return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }
    return '';
  }

  const calculateTotalPrice = (selectedTimePeriod) => {
    const today = new Date();
    const oneWeekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const oneMonthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    const filteredData =
      selectedTimePeriod === "day"
        ? clientData.filter(
            (item) =>
              new Date(item.dataValue).toDateString() === today.toDateString()
          )
        : selectedTimePeriod === "week"
        ? clientData.filter(
            (item) =>
              new Date(item.dataValue) >= oneMonthAgo &&
              new Date(item.dataValue) <= today
          )
        : clientData;

    console.log("Filtered Data:", filteredData);

    const total = filteredData.reduce(
      (total, price) => total + parseInt(price.clientValue),
      0
    );

    return total;
  };

  // Example usage:
  const totalDay = calculateTotalPrice("day");
  const totalWeek = calculateTotalPrice("week");
  const totalMonth = calculateTotalPrice("month");

  ////////////////////////////////////////////////////////////////////////////

  function calculateTotalValue(arr) {
    return arr.reduce((accumulator, item) => {
      const newNumber =
        parseInt(item.clientValue) - parseInt(item.newPriceNumber);

      if (newNumber < 0) {
        return accumulator + newNumber;
      }

      return accumulator;
    }, 0);
  }

  const result = calculateTotalValue(clientData);

  return (
    <div className="main-content">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="d-flex align-center">
              <h1 className="fs-2">Bosh sahifa</h1>
              <button
                className="btn btn-xs ml-5 text-white hover py-0 px-2 bradius"
                style={{ backgroundColor: "#f18024", fontSize: "12px" }}
              >
                Bir haftalik
              </button>
              <button
                className="btn btn-xs ml-2 text-white py-0 px-2 bradius"
                style={{ backgroundColor: "#f18024", fontSize: "12px" }}
              >
                Tanlanmagan
              </button>
            </div>
            <div className="separator mb-5 mt-4"></div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <div className="row">
              <div className="h5 ml-2">Sotuvlar</div>
              {salesInformation.map((item) => {
                let totalValue;

                if (item.title === "Bugun") {
                  totalValue = totalDay;
                } else if (item.title === "Неделя") {
                  totalValue = totalWeek;
                } else if (item.title === "Месяц") {
                  totalValue = totalMonth;
                } else {
                  return null; 
                }

                return (
                  <div key={item.id} className="col-md-4 mb-3">
                    <div className="card mb-4 text-center px-4 py-8 rounded-3 border-none bg-white">
                      <div className="card-body">
                        <FontAwesomeIcon
                          icon={item.icon}
                          className="icon-cards"
                        />
                        <p className="card-text font-weight-semibold mb-0">
                          {item.title}
                        </p>
                        <p className="lead text-center text-nowrap">{formatLargeNumber(totalValue)}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Block with 2 smaller blocks */}

          <div className="col-md-6">
            <div className="row">
              <div className="h5 ml-2">O'zaro hisob-kitoblar</div>
              {salesInformation.slice(3).map((item) => (
                <div key={item.id} className="col-md-6 mb-3">
                  <div className="card mb-4 text-center px-4 py-8 rounded-3 border-none bg-white">
                    <div className="card-body">
                      <FontAwesomeIcon
                        icon={item.icon}
                        className="icon-cards"
                      />
                      <p className="card-text font-weight-semibold mb-0">
                        {item.title}
                      </p>
                      <p className="lead text-center">
                        {item.id === 19 && formatLargeNumber(result)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
