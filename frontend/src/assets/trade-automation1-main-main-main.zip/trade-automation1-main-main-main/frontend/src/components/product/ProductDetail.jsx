
import "./ProductDetail.css";
import ModalComponent from "./ModalComponent";
import ProductHeader from "./ProductHeader";
import ProductTable from "./ProductTable";
import axios from 'axios'
import { useState } from "react";


function ProductDetail({handleFormSubmit,handleInputChange,productArray, productData,setProductArray,showModal,setShowModal,loading, fetchProductData}) {

  const [searchProduct,setSearchProduct] = useState("")


  const filteredProduct = productArray.filter((product) =>
  product.productName.toUpperCase().includes(searchProduct.toUpperCase())
);

  

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const calculateTotalPurchasedPrice = () => {
    return productArray.reduce(
      (total, product) => total + parseInt((product.sotibOlinganNarxi || 0)),
      0
    );
  };

  const deleteItem = async (id) => {
    try {
      // Make a DELETE request to your server to delete the item with the specified id
      await axios.delete(`http://localhost:5000/api/products/${id}`);
  
      // Update the productArray state and local storage
      const updatedArray = productArray.filter((item) => item.id !== id);
      setProductArray(updatedArray);
      localStorage.setItem("productArray", JSON.stringify(updatedArray));
    } catch (error) {
      console.error("Error in deleteItem:", error);
    }
  };
  
  
  return (
    <div className="container">
      <main className="main-content">
        <ProductHeader
        productArray={productArray}
        setSearchProduct={setSearchProduct}
        searchProduct={searchProduct}
         OpenModal={handleOpenModal}
         title = "Mahsulotlar ro'yxati"
         excelButtonLabel = "Mahsulotlarni Exceldan qo'shish"
         filterButtonLabel = "Filtr"
         loadExcelButtonLabel = "Excel-da yuklab olish"
         addProduct = "Yangi mahsulot qo'shish"
          itemTable = "Mahsulotlar ro'yxati"
          />
        {showModal && (
          <ModalComponent
            handleCloseModal={handleCloseModal}
            handleInputChange={handleInputChange}
            handleFormSubmit={handleFormSubmit}
            productData={productData}
            productArray={productArray}
          />
        )}
        <ProductTable
          productArray={productArray}
          totalPurchasedPrice={calculateTotalPurchasedPrice()}
          deleteItem={deleteItem}
         loading={loading}
         fetchProductData={fetchProductData}
         filteredProduct={filteredProduct}
         setSearchProduct={setSearchProduct}
        />
      </main>
    </div>
  );
}

export default ProductDetail;
