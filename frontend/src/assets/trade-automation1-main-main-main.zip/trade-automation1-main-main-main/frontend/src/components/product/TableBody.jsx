import PropTypes from "prop-types";
import Loader from "../Loader";
import { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisVertical } from "@fortawesome/free-solid-svg-icons";

function TableBody({
  productArray,
  openDeleteModal,
  loading,
  handleEditProduct,
  filteredProduct
}) {
 
  function formatLargeNumber(number) {
    if (typeof number !== 'undefined' && number !== null) {
      return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }
    return '';
  } 

  const [isOpenMap, setIsOpenMap] = useState({});

  
  const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  const renderValueOrFallback = (value, fallback) => {
    return value.length !== 0 ? value : fallback;
  };

  const toggleDropdown = (id) => {
    setIsOpenMap((prevIsOpenMap) => ({
      ...prevIsOpenMap,
      [id]: !prevIsOpenMap[id],
    }));
  };

  const handleActionClick = (productId, action) => {
    if (action === "edit") {
      handleEditProduct(productId);
    } else if (action === "delete") {
      openDeleteModal(productId);
    }
    // Close the dropdown after an action is clicked
    setIsOpenMap((prevIsOpenMap) => ({
      ...prevIsOpenMap,
      [productId]: false,
    }));
  };

  return (
    <tbody>
      {loading ? (
        <tr>
          <td colSpan="12">
            <Loader />
          </td>
        </tr>
      ) : productArray.length === 0 ? (
        <tr className="text-center">
          <td colSpan="12">
            <h4 className="fs-5">Mahsulot topilmadi</h4>
          </td>
        </tr>
      ) : (
        filteredProduct.map((product, index) => (
          <tr key={product.id} className={` text-nowrap ${product.oramlarSoni < 10 ? "table-danger": ""}`}  >
            <th scope="row">{index + 1}</th>
            <td className="text-primary fs-5 pt-0 text-wrap">
              {capitalizeFirstLetter(product.productName)}
            </td>
            <td>{renderValueOrFallback(product.turkum, "Tanlanmagan")}</td>
            <td>{formatLargeNumber(product.sotishNarxi)} so'm</td>
            <td>{renderValueOrFallback(formatLargeNumber(product.ulgurjiNarxi), "0")} so'm</td>
            <td>{renderValueOrFallback(formatLargeNumber(product.sotibOlinganNarxi), "0")} so'm</td>
            <td>{product.olchovBirligi}</td>
            <td>{renderValueOrFallback(product.oramlarNomi, "Tanlanmagan")}</td>
            <td>{renderValueOrFallback(formatLargeNumber(product.oramlarSoni), "0")}</td>
            <td className="text-wrap">
              {product.creationDateTime
                ? new Date(product.creationDateTime).toLocaleString()
                : "Unknown"}
            </td>
            <td className="d-flex justify-between border-none float-end">
            <button
            className="pr-3" 
            onClick={() =>toggleDropdown(product.id)} >
            <FontAwesomeIcon icon={faEllipsisVertical} />
      </button>
      {isOpenMap[product.id] && (
         <ul className="pointer bg-opacity-5">
         <li
          className="pointer"
         onClick={() => handleActionClick(product.id, 'edit')}>
           Tanrirlash
         </li>
         <li 
         className="c-pointer"
         onClick={() => handleActionClick(product.id, 'delete')}>
           O'chirish
         </li>
       </ul>
      )}
            </td>
          </tr>
        ))
      )}
    </tbody>
  );
}

TableBody.propTypes = {
  productArray: PropTypes.array.isRequired,
  openDeleteModal: PropTypes.func.isRequired,
  handleEditProduct: PropTypes.func.isRequired,
};

export default TableBody;
