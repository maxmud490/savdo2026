import { useState, useEffect } from "react";
import ButtonOrange from "../ButtonOrange";
import ButtonRed from "../ButtonRed";
import ModalComponent from "../product/ModalComponent";

function SalesFormComponent({
  handleCloseModal,
  handleClickClient,
  handleSubmit,
  salesData,
  handleChange,
  totalValue,
  salesArray,
  allTotalValue,
  showClientModal,
  handleClientSubmit,
  value,
  setValue,
  productArray,
  setSalesArray,
  buttonDisabled,
  setButtonDisabled={setButtonDisabled}
}) {
  const [suggestedProducts, setSuggestedProducts] = useState([]);
  const [productCount, setProductCount] = useState("");
  const resetSalesArray = () => {
    setSalesArray([]); // Set salesArray to an empty array
  };

  useEffect(() => {
    setSuggestedProducts([]);
    const filteredProducts = productArray.filter(
      (product) =>
        product.productName.toLowerCase().includes(value.toLowerCase()) &&
        !salesArray.some(
          (salesItem) => salesItem.productNameValue === product.productName
        )
    );

    // Set the filtered products as suggestions
    setSuggestedProducts(filteredProducts);
  }, [value, productArray, salesArray]);

  const handleInput = (e) => {
    const enteredValue = e.target.value.toLowerCase();
    const isInDatalist = suggestedProducts.some(
      (product) => product.productName.toLowerCase() === enteredValue
    );

    if (!isInDatalist) {
      setValue("");
      setProductCount(0); // Reset productCount if no matching product is found
    } else {
      setValue(enteredValue);

      const product = productArray.find(
        (product) => product.productName.toLowerCase() === enteredValue
      );

      if (product && product.oramlarSoni !== undefined) {
        const count = product.oramlarSoni || 0;
        setProductCount(count);
      } else {
        setProductCount(0);
      }
    }
  };

  function formatLargeNumber(number) {
    if (typeof number !== 'undefined' && number !== null) {
      return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }
    return '';
  }

  const handleClose = () => {
    handleCloseModal();
    resetSalesArray();
    setButtonDisabled(false)
  }

  // Now you can use the productCount variable wherever needed in your component

  return (
    <>
      <div className="modal_content pb-5">
        <div className="row">
          <div className="col-6 pt-4 ">
            <h5 className="d-block fs-5">Yangi sotuv</h5>
          </div>
          <div className="col-6 d-flex justify-evenly p-4">
            <ButtonOrange>Основной склад</ButtonOrange>
            <ButtonRed>Tasdiqlanmagan</ButtonRed>
            <span
              onClick={handleClose}
              className="close"
            >
              &times;
            </span>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <ButtonRed>Saqlash va chekga chiqazish</ButtonRed>
          </div>
          <div className="col-6 text-right">
            <button
              className={`btn w-xs-100 my-2 btn-sm px-3 ${
                !buttonDisabled ? "disabled" : "btn-red"
              }`}
              onClick={handleClickClient}
            >
              Mijoz tolovi
            </button>
          </div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="row mt-5">
            <div className="col-6">
              <div className="card shadow p-5 mt-1 mb-3">
                <div className="input-group mb-3">
                  <input
                    name="dataValue"
                    value={salesData.dataValue}
                    onChange={handleChange}
                    type="date"
                    className="form-control-sm form-control"
                  />
                </div>
                <div className="input-group mb-3">
                  <span className="input-group-text">Mijoz</span>
                  <input
                    name="clientName"
                    value={salesData.clientName}
                    onChange={handleChange}
                    list="productSuggestions"
                    placeholder="Mijozni ismini kiriting"
                    type="text"
                    className="form-control-sm form-control"
                    required
                  />
                  <datalist id="productSuggestions">
                    {suggestedProducts.map((product) => (
                      <option key={product._id} value={product.productName} />
                    ))}
                  </datalist>
                  <span
                    title="Добавить нового клиента"
                    className="input-group-text c-pointer"
                  >
                    +
                  </span>
                </div>
                <div className="input-group">
                  <span className="input-group-text">Narxi</span>
                  <input
                    name="productPrice"
                    value={salesData.productPrice}
                    onChange={handleChange}
                    placeholder={
                      productArray.find(
                        (product) =>
                          product.productName === salesData.productNameValue
                      )?.sotishNarxi || "0"
                    }
                    type="number"
                    className="form-control-sm form-control"
                    required
                  />
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="card shadow p-5 mt-1 mb-3">
                <div className="input-group mb-3">
                  <input
                    name="workman"
                    value={salesData.workman}
                    onChange={handleChange}
                    type="text"
                    placeholder="Mas'ul xodimni tanlang"
                    className="form-control c-pointer form-control-sm"
                  />
                  <span className="input-group-text">+</span>
                </div>
                <div className="input-group mb-3">
                  <span className="input-group-text">Mahsulot</span>
                  <input
                    name="productNameValue"
                    value={
                      productArray.find(
                        (product) =>
                          product.productName === salesData.productNameValue
                      )?.productName || ""
                    }
                    onInput={handleInput}
                    list="productSuggestions"
                    onChange={handleChange}
                    placeholder="Mahsulot nomini kiriting"
                    type="text"
                    className="form-control form-control-sm c-pointer w-80"
                    required
                  />
                  {productCount && (
                    <div>
                      <span className=" pl-2 pr-2 rounded-pill border border-dark text-white fs-6 text-center bg-danger">
                        Omborda {productCount} ta mahsulot bor!
                      </span>
                    </div>
                  )}
                  <datalist id="productSuggestions">
                    {/* Display the suggested products as options */}
                    {suggestedProducts.map((product) => (
                      <option key={product._id} value={product.productName} />
                    ))}
                  </datalist>
                </div>
                <div className="input-group">
                  <span className="input-group-text">Soni</span>
                  <input
                    name="productNumber"
                    onInput={handleInput}
                    value={salesData.productNumber}
                    onChange={handleChange}
                    type="number"
                    className="form-control-sm form-control "
                    required
                  />
                  <br />
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="d-flex justify-between">
              <div>
                <button
                  className="btn w-xs-100 my-2 btn-orange btn-sm px-3"
                  type="submit"
                >
                  Qoshish
                </button>
              </div>
              <div>
                <h3 className="fs-3">Jami: {formatLargeNumber(totalValue)}</h3>
              </div>
            </div>
          </div>
        </form>
        <div className="row mt-2">
          <div className="col-12">
            <div>
              <h3 className="fs-4">Ro‘yxat</h3>
            </div>
            <div>
              <table className="table table-hover mt-3">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Mahsulot nomi</th>
                    <th scope="col">Soni</th>
                    <th scope="col">O'ramlar soni</th>
                    <th scope="col">Sotish narxi</th>
                    <th scope="col">Jami</th>
                    <th scope="col">O'chirish</th>
                  </tr>
                </thead>
                <tbody>
                  {salesArray.map((salesItem, index) => {
                    const correspondingProduct = productArray.find(
                      (product) =>
                        product.productName === salesItem.productNameValue
                    );

                    return (
                      <tr key={index}>
                        <th scope="row">{index + 1}</th>
                        <td>{salesItem.productNameValue}</td>
                        <td>{salesItem.productNumber}</td>
                        <td>
                          {correspondingProduct
                            ? correspondingProduct.oramlarSoni || 0
                            : 0}
                        </td>
                        <td>{salesItem.productPrice}</td>
                        <td>
                          {salesItem.productNumber * salesItem.productPrice}
                        </td>
                        <td>
                          <span className="c-pointer">X</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <h3 className="text-end fs-4">Umumiy qiymati:{formatLargeNumber(allTotalValue)}</h3>
        </div>
      </div>
      {showClientModal && (
        <div className="modal_container">
          <div className="modal_content p-4">
            <form onSubmit={handleClientSubmit}>
              <input
                value={value}
                onChange={(e) => setValue(e.target.value)}
                type="number"
                className="form form-control"
              />
              <button className="btn w-xs-100 my-2 btn-red btn-sm px-3">
                ok
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

export default SalesFormComponent;
