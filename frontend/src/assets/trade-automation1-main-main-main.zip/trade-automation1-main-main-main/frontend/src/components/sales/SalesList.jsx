import { useState } from "react";
import ProductHeader from "../product/ProductHeader";
import SalesFormComponent from "./SalesFormComponent";
import Loader from "../Loader";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisVertical } from "@fortawesome/free-solid-svg-icons";
import ConfirmDeleteSales from "./ConfirmDeleteSales";

// import { ToastContainer, toast } from 'react-toastify';

function SalesList({
  handleSalesModal,
  clientData,
  salesOpenModal,
  handleCloseModal,
  handleClickClient,
  handleSubmit,
  salesData,
  handleChange,
  totalValue,
  salesArray,
  allTotalValue,
  showClientModal,
  setShowClientModal,
  setSalesData,
  setSalesArray,
  handleClientSubmit,
  value,
  setValue,
  handleDelete,
  productArray,
  loading,
  buttonDisabled,
  setButtonDisabled
}) {
  const [isOpenMap, setIsOpenMap] = useState({});
  const [isOpenDeleteModal, setIsOpenDeleteModal] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);

  function formatLargeNumber(number) {
    if (typeof number !== 'undefined' && number !== null) {
      return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }
    return '';
  }
  

  const { total, totalPrice, debtPrice } = clientData.reduce(
    (accumulator, item) => {
      const newPrice = parseInt(item.newPrice);
      const clientValue = parseInt(item.clientValue);

      accumulator.total += newPrice;
      accumulator.totalPrice += clientValue;
      accumulator.debtPrice += newPrice - clientValue;

      return accumulator;
    },
    { total: 0, totalPrice: 0, debtPrice: 0 }
  );

  const toggleDropdown = (id) => {
    setIsOpenMap((prevIsOpenMap) => ({
      ...prevIsOpenMap,
      [id]: !prevIsOpenMap[id],
    }));
  };

  const handleActionClick = (productId, action) => {
    if (action === "edit") {
      // handleEditProduct(productId);
    } else if (action === "delete") {
      setIsOpenDeleteModal(true);
      setItemToDelete(productId);
    }
    // Close the dropdown after an action is clicked
    setIsOpenMap((prevIsOpenMap) => ({
      ...prevIsOpenMap,
      [productId]: false,
    }));
  };
  const handleConfirmDelete = () => {
    // Perform delete operation using itemToDelete
    handleDelete(itemToDelete);
    setIsOpenDeleteModal(false);
    setItemToDelete(null);
  };

  return (
    <>
      <div className="main-content">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <ProductHeader
                title="Sotuvlar ro'yxati"
                excelButtonLabel="Chakana savdo"
                filterButtonLabel="Filtr"
                loadExcelButtonLabel="Excel-da yuklab olish"
                addProduct="Yangi sotuv"
                itemTable="Sotuvlar ro'yxati"
                OpenModal={handleSalesModal}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-12">
              <div className="card mb-4 table-container">
                <div className="card-body p-5">
                  <h3 style={{ fontSize: "1.2rem" }}>Sotuvlar royxati</h3>
                  <table className="table table-bordered mt-3">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mijoz</th>
                        <th scope="col">Sotuv holati</th>
                        <th scope="col">To'lov holati</th>
                        <th scope="col">Jami narxi</th>
                        <th scope="col">To'lov</th>
                        <th scope="col">Naqd to'lov</th>
                        <th scope="col">Bank kartasi orqali to'lov</th>
                        <th scope="col">Qarzga</th>
                        <th scope="col">Sotilgan vaqti</th>
                        <th scope="col">Setting</th>
                      </tr>
                    </thead>

                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan="12">
                            <Loader />
                          </td>
                        </tr>
                      ) : (
                        clientData.map((item, index) => (
                          <tr key={index} className="text-nowrap">
                            <th scope="row">{index + 1}</th>
                            <td className="text-primary fs-5 pt-0">
                              {item.clientName}
                            </td>
                            <td>Tastiqlangan</td>
                            <td>naqd</td>
                            <td>{formatLargeNumber(item.newPrice)} som</td>
                            <td>{formatLargeNumber(item.clientValue)} som</td>
                            <td>---</td>
                            <td>---</td>
                            <td>
                              {formatLargeNumber(
                                parseInt(item.newPrice) - item.clientValue
                              )}{" "}
                              som
                            </td>

                            <td className="text-wrap">
                              {item.creationDateTime &&
                              !isNaN(new Date(item.creationDateTime)) // Check if dataValue is a valid date
                                ? new Date(
                                    item.creationDateTime
                                  ).toLocaleString()
                                : "Unknown"}
                            </td>

                            <td className="d-flex justify-between border-none float-end">
                              <button
                                type="button"
                                className="pr-3"
                                onClick={() => toggleDropdown(item.id)}
                              >
                                <FontAwesomeIcon icon={faEllipsisVertical} />
                              </button>
                              {isOpenMap[item.id] && (
                                <ul className="pointer bg-opacity-5">
                                  <li
                                    className="pointer"
                                    onClick={() =>
                                      handleActionClick(item.id, "edit")
                                    }
                                  >
                                    Tanrirlash
                                  </li>
                                  <li
                                    className="c-pointer"
                                    onClick={() =>
                                      handleActionClick(item.id, "delete")
                                    }
                                  >
                                    O'chirish
                                  </li>
                                </ul>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              </div>
              <ul className="list-group list-group-horizontal-xxl fs-6">
                <li className="list-group-item ">
                  Jami - Jami narxi: {formatLargeNumber(total)}
                </li>
                <li className="list-group-item">
                  Jami - To'lov: {formatLargeNumber(totalPrice)}
                </li>
                <li className="list-group-item">Jami - Naqd to'lov: 0</li>
                <li className="list-group-item">
                  Jami - Bank kartasi orqali to'lov: 0
                </li>
                <li className="list-group-item">
                  Jami - Qarz: {formatLargeNumber(debtPrice)}
                </li>
              </ul>
           
          </div>
        </div>
      </div>
      {salesOpenModal && (
        <div className="modal_container">
          <SalesFormComponent
            handleCloseModal={handleCloseModal}
            handleClickClient={handleClickClient}
            handleSubmit={handleSubmit}
            salesData={salesData}
            handleChange={handleChange}
            totalValue={totalValue}
            salesArray={salesArray}
            allTotalValue={allTotalValue}
            showClientModal={showClientModal}
            setShowClientModal={setShowClientModal}
            setSalesData={setSalesData}
            setSalesArray={setSalesArray}
            handleClientSubmit={handleClientSubmit}
            value={value}
            setValue={setValue}
            productArray={productArray}
            buttonDisabled={buttonDisabled}
            setButtonDisabled={setButtonDisabled}
          />
        </div>
      )}

      {isOpenDeleteModal && (
        <ConfirmDeleteSales
          handleConfirmDelete={handleConfirmDelete}
          handleCloseDeleteModal={() => setIsOpenDeleteModal(false)}
        />
      )}
    </>
  );
}
export default SalesList;
